<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AlapitvanyController;
use App\Http\Controllers\AdomanyozoController;
use App\Http\Controllers\AdomanyController;
use App\Http\Controllers\AnyagController;
use App\Http\Controllers\AdomanyNevController;
use App\Http\Controllers\KiszallitasController;
use App\Http\Controllers\EmberController;

Route::get('/ember',[EmberController::class,'index']);

Route::get('/alapitvany',[AlapitvanyController::class,'index']);
Route::post('/alapitvany',[AlapitvanyController::class,'store']);
Route::put('/alapitvany/{id}',[AlapitvanyController::class,'update']);
Route::delete('/alapitvany/{id}',[AlapitvanyController::class,'destroy']);
Route::get('/alapitvany/{id}',[AlapitvanyController::class,'getById']);

Route::get('/adomanyozo', [AdomanyozoController::class, 'index']);
Route::post('/adomanyozo', [AdomanyozoController::class, 'store']);
Route::put('/adomanyozo/{id}', [AdomanyozoController::class, 'update']);
Route::delete('/adomanyozo/{id}', [AdomanyozoController::class, 'destroy']);
Route::get('/adomanyozo/{id}',[AdomanyozoController::class,'getById']);

Route::get('/adomany',[AdomanyController::class,'index']);
Route::post('/adomany', [AdomanyController::class, 'store']);
Route::put('/adomany/{id}', [AdomanyController::class, 'update']);
Route::delete('/adomany/{id}', [AdomanyController::class, 'destroy']);
Route::get('/adomany/{id}',[AdomanyController::class,'getById']);
Route::get('/adomany/nagyobb/{db}',[AdomanyController::class,'getBiggerNumberOfPieces']);
Route::get('/adomany/kisebb/{db}',[AdomanyController::class,'getSmallerNumberOfPieces']);

Route::get('/anyag', [AnyagController::class, 'index']);
Route::post('/anyag', [AnyagController::class, 'store']);
Route::put('/anyag/{id}', [AnyagController::class, 'update']);
Route::delete('/anyag/{id}', [AnyagController::class, 'destroy']);
Route::get('/anyag/{id}',[AnyagController::class,'getById']);

Route::get('/adomanynev', [AdomanyNevController::class, 'index']);
Route::post('/adomanynev', [AdomanyNevController::class, 'store']);
Route::put('/adomanynev/{id}', [AdomanyNevController::class, 'update']);
Route::delete('/adomanynev/{id}', [AdomanyNevController::class, 'destroy']);
Route::get('/adomanynev/{id}',[AdomanyNevController::class,'getById']);

Route::get('/kiszallitas', [KiszallitasController::class, 'index']);
Route::post('/kiszallitas', [KiszallitasController::class, 'store']);
Route::put('/kiszallitas/{id}', [KiszallitasController::class, 'update']);
Route::delete('/kiszallitas/{id}', [KiszallitasController::class, 'destroy']);
Route::get('/kiszallitas/{id}', [KiszallitasController::class, 'getById']);