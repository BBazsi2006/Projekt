import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdomanyokKomponens } from './adomanyok-komponens';

describe('AdomanyokKomponens', () => {
  let component: AdomanyokKomponens;
  let fixture: ComponentFixture<AdomanyokKomponens>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdomanyokKomponens]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdomanyokKomponens);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
