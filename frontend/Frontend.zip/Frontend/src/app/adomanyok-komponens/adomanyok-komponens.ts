import { Component } from '@angular/core';

@Component({
  selector: 'app-adomanyok-komponens',
  imports: [],
  templateUrl: './adomanyok-komponens.html',
  styleUrl: './adomanyok-komponens.css',
})
export class AdomanyokKomponens {

}
