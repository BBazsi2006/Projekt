import { Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

export const routes: Routes = [];

import { FooldalKomponens } from './fooldal-komponens/fooldal-komponens';
import { AdomanyokKomponens } from './adomanyok-komponens/adomanyok-komponens';
import { BejelentkezesKomponens } from './bejelentkezes-komponens/bejelentkezes-komponens';
import { KosarKomponens } from './kosar-komponens/kosar-komponens';

const navigacio: Routes = [
  { path: '', component: FooldalKomponens },
  { path: 'adomanyok', component: AdomanyokKomponens },
  { path: 'bejelentkezes', component: BejelentkezesKomponens },
  { path: 'kosar', component: KosarKomponens },
  //{ path: 'alapitvany', component:  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
