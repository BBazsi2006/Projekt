import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FooldalKomponens } from './fooldal-komponens';

describe('FooldalKomponens', () => {
  let component: FooldalKomponens;
  let fixture: ComponentFixture<FooldalKomponens>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FooldalKomponens]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FooldalKomponens);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
