import { Component } from '@angular/core';

@Component({
  selector: 'app-fooldal-komponens',
  imports: [],
  templateUrl: './fooldal-komponens.html',
  styleUrl: './fooldal-komponens.css',
})
export class FooldalKomponens {

}
