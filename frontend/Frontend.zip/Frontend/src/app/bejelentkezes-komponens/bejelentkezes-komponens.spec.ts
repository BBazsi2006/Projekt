import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BejelentkezesKomponens } from './bejelentkezes-komponens';

describe('BejelentkezesKomponens', () => {
  let component: BejelentkezesKomponens;
  let fixture: ComponentFixture<BejelentkezesKomponens>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BejelentkezesKomponens]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BejelentkezesKomponens);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
