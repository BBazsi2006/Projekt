import { Component } from '@angular/core';

@Component({
  selector: 'app-bejelentkezes-komponens',
  imports: [],
  templateUrl: './bejelentkezes-komponens.html',
  styleUrl: './bejelentkezes-komponens.css',
})
export class BejelentkezesKomponens {

}
