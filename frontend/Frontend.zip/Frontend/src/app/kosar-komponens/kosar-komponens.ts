import { Component } from '@angular/core';

@Component({
  selector: 'app-kosar-komponens',
  imports: [],
  templateUrl: './kosar-komponens.html',
  styleUrl: './kosar-komponens.css',
})
export class KosarKomponens {

}
