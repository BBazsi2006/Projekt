import { Component } from '@angular/core';

@Component({
  selector: 'app-navigacio-komponens',
  imports: [],
  templateUrl: './navigacio-komponens.html',
  styleUrl: './navigacio-komponens.css',
})
export class NavigacioKomponens {

}
