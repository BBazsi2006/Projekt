import { TestBed } from '@angular/core/testing';

import { AdomanyNevService } from './adomany-nev-service';

describe('AdomanyNevService', () => {
  let service: AdomanyNevService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdomanyNevService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
