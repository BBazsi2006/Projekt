import { TestBed } from '@angular/core/testing';

import { KiszallitasService } from './kiszallitas-service';

describe('KiszallitasService', () => {
  let service: KiszallitasService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KiszallitasService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
