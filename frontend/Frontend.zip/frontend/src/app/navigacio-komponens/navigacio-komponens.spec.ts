import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavigacioKomponens } from './navigacio-komponens';

describe('NavigacioKomponens', () => {
  let component: NavigacioKomponens;
  let fixture: ComponentFixture<NavigacioKomponens>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NavigacioKomponens]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NavigacioKomponens);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
