import { Component } from '@angular/core';
import { Router, RouterLink, RouterModule } from '@angular/router';
import { KosarService } from '../kosar-service';

@Component({
  selector: 'app-navigacio-komponens',
  standalone: true,
  imports: [RouterModule, RouterLink],
  templateUrl: './navigacio-komponens.html',
  styleUrl: './navigacio-komponens.css',
})
export class NavigacioKomponens {
  darabszam: number = 0;
  bejelentkezve: boolean = false;

  constructor(
    public kosarService: KosarService,
    private router: Router
  ) {}

  ngDoCheck() {
    this.bejelentkezve = !!localStorage.getItem('user');
  }

  kijelentkezes() {
    localStorage.removeItem('user');
    this.kosarService.betoltKosar();
    this.router.navigate(['/bejelentkezes']);
  }
}