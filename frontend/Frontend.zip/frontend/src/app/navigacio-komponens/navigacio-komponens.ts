import { Component, DoCheck } from '@angular/core';
import { Router, RouterLink, RouterModule } from '@angular/router';
import { KosarService } from '../kosar-service';

@Component({
  selector: 'app-navigacio-komponens',
  standalone: true,
  imports: [RouterModule, RouterLink],
  templateUrl: './navigacio-komponens.html',
  styleUrl: './navigacio-komponens.css',
})
export class NavigacioKomponens implements DoCheck {
  darabszam: number = 0;
  bejelentkezve: boolean = false;

  constructor(
    public kosarService: KosarService,
    private router: Router
  ) {}

  ngDoCheck(): void {
    this.bejelentkezve = !!localStorage.getItem('user');
  }

  kijelentkezes(): void {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    this.kosarService.betoltKosar();
    this.router.navigate(['/bejelentkezes']);
  }

  isAlapitvany(): boolean {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user.tipus === 1;
  }
}