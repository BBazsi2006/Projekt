export interface Ember {
  id: number;
  kategoria: string;
}