import { AdomanyNev } from "./adomanynev.model";
import { Anyag } from "./anyag.model";

export interface Adomany {
  adomanyId: number;
  darabszam: number;
  nevId: AdomanyNev;
  adomanyanyagId: Anyag;
}