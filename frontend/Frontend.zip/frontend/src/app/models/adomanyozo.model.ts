export interface Adomanyozo {
  adomanyozoId: number;
  nev: string;
  email: string;
  emberId: number;
}