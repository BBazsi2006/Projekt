export interface AdomanyNev {
  adomanynevId: number;
  nev: string;
}