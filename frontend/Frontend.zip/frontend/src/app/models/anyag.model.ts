export interface Anyag {
  anyagId:number;
  anyagnev:string
}