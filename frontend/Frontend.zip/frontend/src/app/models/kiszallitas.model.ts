import { Adomany } from "./adomany.model";
import { Alapitvany } from "./alapitvany.model";

export interface Kiszallitas {
  id: number;
  alapitvanyId: number;
  adomanyId: number;
  mennyiseg: number;
  megrendelesDatuma: string;
  elszallitasDatuma: string;
  pontosCim?: string;
  teljesitve: boolean;

  alapitvany?: Alapitvany;
  adomany?: Adomany;
}