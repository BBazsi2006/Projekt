export interface Alapitvany {
  alapitvanyId: number;
  cegnev: string;
  helyszin: string;
  telszam: string;
  email: string;
  emberId: number
}