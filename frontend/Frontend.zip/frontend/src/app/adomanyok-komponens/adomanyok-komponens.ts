import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

import { AdomanyService } from '../adomany-service';
import { AdomanyNevService } from '../adomany-nev-service';
import { AnyagService } from '../anyag-service';

@Component({
  selector: 'app-adomanyok-komponens',
  standalone: true,
  imports: [CommonModule, FormsModule, MatSnackBarModule],
  templateUrl: './adomanyok-komponens.html',
  styleUrl: './adomanyok-komponens.css',
})
export class AdomanyokKomponens {
  adomanyok = signal<any[]>([]);
  adomanynevek = signal<any[]>([]);
  anyagok = signal<any[]>([]);

  ujDarabszam: number = 1;
  kivalasztottNevId: number | null = null;
  kivalasztottAnyagId: number | null = null;
  selectedFile: File | null = null;

  constructor(
    private adomanyService: AdomanyService,
    private adomanyNevService: AdomanyNevService,
    private anyagService: AnyagService,
    private snackBar: MatSnackBar
  ) {}

  uzenet(szoveg: string, tipus: 'success' | 'error' | 'warn' = 'success') {
    this.snackBar.open(szoveg, 'Bezár', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
      panelClass: [`${tipus}-snackbar`]
    });
  }

  ngOnInit() {
    const userAdat = localStorage.getItem('user');

    if (userAdat) {
      const user = JSON.parse(userAdat);

      if (user.tipus == 2 && user.email) {
        this.adomanyService.getByAdomanyozoEmail(user.email).subscribe({
          next: (valasz: any) => {
            console.log('Saját adományok:', valasz);
            this.adomanyok.set(valasz);
          },
          error: (err) => {
            console.log('Hiba a saját adományok lekérésekor:', err);
            this.uzenet('Nem sikerült betölteni a saját adományokat.', 'error');
          }
        });
      } else {
        this.adomanyService.getAll().subscribe({
          next: (valasz: any) => this.adomanyok.set(valasz),
          error: (err) => {
            console.log('Hiba az adományok lekérésekor:', err);
            this.uzenet('Nem sikerült betölteni az adományokat.', 'error');
          }
        });
      }
    } else {
      this.adomanyService.getAll().subscribe({
        next: (valasz: any) => this.adomanyok.set(valasz),
        error: (err) => {
          console.log('Hiba az adományok lekérésekor:', err);
          this.uzenet('Nem sikerült betölteni az adományokat.', 'error');
        }
      });
    }

    this.adomanyNevService.getAll().subscribe({
      next: (valasz: any) => {
        console.log('Adománynevek:', valasz);
        this.adomanynevek.set(valasz);
      },
      error: (err) => {
        console.log('Hiba az adománynevek lekérésekor:', err);
        this.uzenet('Nem sikerült betölteni az adományneveket.', 'error');
      }
    });

    this.anyagService.getAll().subscribe({
      next: (valasz: any) => {
        console.log('Anyagok:', valasz);
        this.anyagok.set(valasz);
      },
      error: (err) => {
        console.log('Hiba az anyagok lekérésekor', err);
        this.uzenet('Nem sikerült betölteni az anyagokat.', 'error');
      }
    });
  }

  feltoltes() {
    if (!this.ujDarabszam || !this.kivalasztottNevId || !this.kivalasztottAnyagId) {
      this.uzenet('Minden mezőt ki kell tölteni!', 'warn');
      return;
    }

    const userAdat = localStorage.getItem('user');

    if (!userAdat) {
      this.uzenet('Be kell jelentkezni a feltöltéshez!', 'warn');
      return;
    }

    const user = JSON.parse(userAdat);

    const formData = new FormData();
    formData.append('darabszam', String(this.ujDarabszam));
    formData.append('adomanyNev', String(this.kivalasztottNevId));
    formData.append('anyag', String(this.kivalasztottAnyagId));
    formData.append('email', user.email);

    if (this.selectedFile) {
      formData.append('kep', this.selectedFile);
    }

    console.log('Küldött darabszam:', this.ujDarabszam);
    console.log('Küldött adomanyNev:', this.kivalasztottNevId);
    console.log('Küldött anyag:', this.kivalasztottAnyagId);
    console.log('Küldött email:', user.email);
    console.log('Küldött fájl:', this.selectedFile);

    this.adomanyService.create(formData).subscribe({
      next: (valasz: any) => {
        console.log('Sikeres mentés:', valasz);
        this.adomanyok.update(lista => [...lista, valasz]);

        this.ujDarabszam = 1;
        this.kivalasztottNevId = null;
        this.kivalasztottAnyagId = null;
        this.selectedFile = null;

        this.uzenet('Sikeres feltöltés!', 'success');
      },
      error: (err) => {
        console.log('Hiba mentés közben:', err);
        console.log('Backend válasz:', err.error);
        this.uzenet('Nem sikerült a feltöltés.', 'error');
      }
    });
  }

  fajlKivalasztva(event: any) {
    if (event.target.files && event.target.files.length > 0) {
      this.selectedFile = event.target.files[0];
      console.log('Kiválasztott fájl:', this.selectedFile);
      this.uzenet('Kép kiválasztva.', 'success');
    }
  }

  torles(id: number) {
    if (!confirm('Biztosan törölni szeretnéd ezt az adományt?')) {
      return;
    }

    this.adomanyService.delete(id).subscribe({
      next: () => {
        this.adomanyok.update(lista => lista.filter(a => a.id !== id));
        this.uzenet('Sikeres törlés!', 'success');
      },
      error: (err) => {
        console.log('Hiba törlés közben:', err);
        this.uzenet('Nem sikerült a törlés.', 'error');
      }
    });
  }
}