import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-fooldal-komponens',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './fooldal-komponens.html',
  styleUrl: './fooldal-komponens.css',
})
export class FooldalKomponens {
  constructor(private router: Router) { }

  adomanyozas() {
    const userAdat = localStorage.getItem('user');

    if (userAdat) {
      const user = JSON.parse(userAdat);

      if (user.tipus == 1) {
        this.router.navigate(['/alapitvanyok']);
      } else if (user.tipus == 2) {
        this.router.navigate(['/adomanyok']);
      }
    } else {
      this.router.navigate(['/login']);
    }
  }

  kiemeltNyitva = false;

  toggleKiemelt() {
    this.kiemeltNyitva = !this.kiemeltNyitva;
  }

  kiemeltEsemeny = {
    cim: 'Tavaszi adománygyűjtő nap',
    datum: '2026.04.18.',
    helyszin: 'Budapest',
    leiras:
      'Szervezetünk egész napos adománygyűjtő eseményt szervez, ahol ruhákat, tartós élelmiszereket, tanszereket, könyveket és használható háztartási eszközöket várunk a segíteni szándékozóktól. A rendezvény célja, hogy közvetlen kapcsolatot teremtsünk az adományozók és a támogatásra szoruló családokat segítő alapítványok között.',
    leiras2:
      'A program során önkénteseink fogadják, rendszerezik és előkészítik a beérkező csomagokat, majd azokat partneralapítványaink segítségével juttatjuk el a rászorulókhoz. Külön figyelmet fordítunk a gyermekes családok, az idősek, valamint a hátrányos helyzetű közösségek támogatására. A rendezvényen tájékoztató beszélgetések, rövid bemutatók és személyes találkozások is lesznek, hogy minden érdeklődő jobban megismerhesse, hogyan válik egy-egy felajánlás valódi segítséggé. Hisszük, hogy a közösségi összefogásnak óriási ereje van, és már egy kisebb adomány is komoly változást hozhat valaki életében.',
  };

  esemenyek = [
    {
      cim: 'Csomagosztás gyermekotthonoknak',
      datum: '2026.04.25.',
      helyszin: 'Szeged',
      leiras:
        'Játékokból, könyvekből és iskolai eszközökből összeállított csomagok kiosztása partnerintézmények részére, külön hangsúlyt fektetve a fejlesztő és oktatási célú adományokra.',
    },
    {
      cim: 'Nyári önkéntes toborzó',
      datum: '2026.05.10.',
      helyszin: 'Debrecen',
      leiras:
        'Olyan segítőket keresünk, akik szívesen részt vennének az adományok szortírozásában, csomagolásában, valamint a nyári rendezvények lebonyolításában.',
    },
    {
      cim: 'Iskolakezdési támogatási akció',
      datum: '2026.08.20.',
      helyszin: 'Országos',
      leiras:
        'Táskák, füzetek, írószerek, digitális eszközök és iskolai felszerelések gyűjtése hátrányos helyzetű diákok számára, hogy könnyebben kezdhessék meg a tanévet.',
    },
  ];
}