import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KiszallitasKomponens } from './kiszallitas-komponens';

describe('KiszallitasKomponens', () => {
  let component: KiszallitasKomponens;
  let fixture: ComponentFixture<KiszallitasKomponens>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [KiszallitasKomponens]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KiszallitasKomponens);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
