import { Component, signal } from '@angular/core';
import { Kiszallitas } from '../models/kiszallitas.model';
import { KiszallitasService } from '../kiszallitas-service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-kiszallitas-komponens',
  imports: [CommonModule, FormsModule],
  templateUrl: './kiszallitas-komponens.html',
  styleUrl: './kiszallitas-komponens.css',
})
export class KiszallitasKomponens {
  kiszallitasok = signal<Kiszallitas[]>([]);

  constructor(private kiszallitasService: KiszallitasService,
    private router: Router
  ) { }

  ngOnInit() {
    const tarolt = localStorage.getItem('user');

    if (!tarolt) {
      this.router.navigate(['/bejelentkezes']);
      return;
    }

    const user = JSON.parse(tarolt);

    if (!user?.admin) {
      this.router.navigate(['/']);
      return;
    }

    this.betoltes();
  }

  betoltes() {
    this.kiszallitasService.getAll().subscribe({
      next: (valasz: Kiszallitas[]) => {
        console.log('Kiszállítások:', valasz);
        console.log('Első elem pontosCim:', valasz[0]?.pontosCim);
        this.kiszallitasok.set(valasz);
      },
      error: (err) => {
        console.log('Hiba a kiszállítások lekérésekor:', err);
      }
    });
  }

  teljesitesValtozas(kiszallitas: Kiszallitas, ertek: boolean) {
    this.kiszallitasService.update(kiszallitas.id, {
      teljesitve: ertek
    }).subscribe({
      next: () => {
        this.kiszallitasok.update(lista =>
          lista.map(k =>
            k.id === kiszallitas.id
              ? { ...k, teljesitve: ertek }
              : k
          )
        );
      },
      error: (err) => {
        console.log('Hiba mentés közben:', err);
        alert('Nem sikerült a státusz módosítása.');
      }
    });
  }

}
