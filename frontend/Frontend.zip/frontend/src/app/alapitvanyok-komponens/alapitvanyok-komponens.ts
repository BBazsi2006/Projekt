import { Component, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { KosarService } from '../kosar-service';
import { CommonModule } from '@angular/common';
import { AdomanyService } from '../adomany-service';
import { AdomanyNevService } from '../adomany-nev-service';
import { AnyagService } from '../anyag-service';

@Component({
  selector: 'app-alapitvanyok-komponens',
  imports: [RouterLink, CommonModule],
  templateUrl: './alapitvanyok-komponens.html',
  styleUrl: './alapitvanyok-komponens.css',
})
export class AlapitvanyokKomponens {
osszesAdomany = signal<any[]>([]);
  megjelenitettAdomanyok = signal<any[]>([]);
  adomanynevek = signal<any[]>([]);
  anyagok = signal<any[]>([]);

  ujDarabszam: number = 1;
  kivalasztottNevId: number | null = null;
  kivalasztottAnyagId: number | null = null;

  constructor(
    private adomanyService: AdomanyService,
    private adomanyNevService: AdomanyNevService,
    private anyagService: AnyagService,
    public kosarService: KosarService
  ) { }

  ngOnInit() {
    const userAdat = localStorage.getItem('user');

    if (userAdat) {
      const user = JSON.parse(userAdat);

      if (user.tipus == 2 && user.email) {
        this.adomanyService.getByAdomanyozoEmail(user.email).subscribe({
          next: (valasz: any) => {
            console.log('Saját adományok:', valasz);
            this.osszesAdomany.set(valasz);
            this.megjelenitettAdomanyok.set(valasz);
          },
          error: (err) => {
            console.log('Hiba a saját adományok lekérésekor:', err);
          }
        });
      } else {
        this.adomanyService.getAll().subscribe({
          next: (valasz: any) => {
            this.osszesAdomany.set(valasz);
            this.megjelenitettAdomanyok.set(valasz);
          }
        });
      }
    } else {
      this.adomanyService.getAll().subscribe({
        next: (valasz: any) => {
          this.osszesAdomany.set(valasz);
          this.megjelenitettAdomanyok.set(valasz);
        }
      });
    }

    this.adomanyNevService.getAll().subscribe({
      next: (valasz: any) => {
        console.log('Adománynevek:', valasz);
        this.adomanynevek.set(valasz);
      },
      error: (err) => {
        console.log('Hiba az adománynevek lekérésekor:', err);
      }
    });

    this.anyagService.getAll().subscribe({
      next: (valasz: any) => {
        console.log('Anyagok:', valasz);
        this.anyagok.set(valasz);
      },
      error: (err) => {
        console.log('Hiba az anyagok lekérésekor', err);
      }
    });
  }

  kategoriaraSzures(adomanyNevId: number) {
    this.kivalasztottNevId = adomanyNevId;

    const szurt = this.osszesAdomany().filter(a => a.adomanyNev?.id === adomanyNevId);
    this.megjelenitettAdomanyok.set(szurt);
  }

  osszesMegjelenitese() {
    this.kivalasztottNevId = null;
    this.megjelenitettAdomanyok.set(this.osszesAdomany());
  }

  kosarbaRak(adomany: any) {
    this.kosarService.addToCart(adomany);
  }
}
