import { Component } from '@angular/core';

@Component({
  selector: 'app-rolunk-komponens',
  imports: [],
  templateUrl: './rolunk-komponens.html',
  styleUrl: './rolunk-komponens.css',
})
export class RolunkKomponens {

}
