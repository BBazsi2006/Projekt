import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RolunkKomponens } from './rolunk-komponens';

describe('RolunkKomponens', () => {
  let component: RolunkKomponens;
  let fixture: ComponentFixture<RolunkKomponens>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RolunkKomponens]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RolunkKomponens);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
