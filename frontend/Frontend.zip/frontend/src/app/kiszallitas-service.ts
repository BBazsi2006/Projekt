import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class KiszallitasService {
  apiUrl = 'http://localhost:8000/api/kiszallitas';

  constructor(private http: HttpClient) {}

  getAll(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  getById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  add(adat: any): Observable<any> {
    return this.http.post(this.apiUrl, adat);
  }

  rendeles(adat: any): Observable<any> {
    return this.http.post(this.apiUrl, adat);
  }

  update(id: number, adat: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, adat);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}