import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BejelentkezesService {

  private apiUrl = 'http://127.0.0.1:8000/api';

  constructor(private http: HttpClient) {}

  regisztralAdomanyozo(adat: any) {
    return this.http.post(`${this.apiUrl}/adomanyozo`, adat);
  }

  regisztralAlapitvany(adat: any) {
    return this.http.post(`${this.apiUrl}/alapitvany`, adat);
  }

  belepes(adat: any) {
    return this.http.post(`${this.apiUrl}/belepes`, adat);
  }
}