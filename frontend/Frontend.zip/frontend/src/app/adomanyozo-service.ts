import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Adomanyozo } from './models/adomanyozo.model';

@Injectable({
  providedIn: 'root',
})
export class AdomanyozoService {
  private apiUrl = 'http://localhost:8000/api/adomanyozo';

  constructor(private http: HttpClient) { }

  // Összes lekérése
  getAll(): Observable<Adomanyozo[]> {
    return this.http.get<Adomanyozo[]>(this.apiUrl);
  }

  // Egy lekérése ID alapján
  getById(id: number): Observable<Adomanyozo> {
    return this.http.get<Adomanyozo>(`${this.apiUrl}/${id}`);
  }

  // Létrehozás
  create(adomanyozo: Adomanyozo): Observable<Adomanyozo> {
    return this.http.post<Adomanyozo>(this.apiUrl, adomanyozo);
  }

  // Módosítás
  update(id: number, adomanyozo: Adomanyozo): Observable<Adomanyozo> {
    return this.http.put<Adomanyozo>(`${this.apiUrl}/${id}`, adomanyozo);
  }

  // Törlés
  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}