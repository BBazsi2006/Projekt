import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

import { KosarService } from '../kosar-service';
import { KiszallitasService } from '../kiszallitas-service';
import { MatFormFieldModule } from '@angular/material/form-field';

@Component({
  selector: 'app-kosar-komponens',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, MatFormFieldModule, MatSnackBarModule],
  templateUrl: './kosar-komponens.html',
  styleUrl: './kosar-komponens.css'
})
export class KosarKomponens {
  pontosCim: string = '';
  maiDatum: string = new Date().toISOString().split('T')[0];
  elszallitasDatuma: string = '';

  constructor(
    public kosarService: KosarService,
    private kiszallitasService: KiszallitasService,
    private snackBar: MatSnackBar
  ) {
    this.elszallitasDatuma = this.szamolElszallitasDatum();
  }

  uzenet(szoveg: string, tipus: 'success' | 'error' | 'warn' = 'success') {
    this.snackBar.open(szoveg, 'Bezár', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
      panelClass: [`${tipus}-snackbar`]
    });
  }

  torles(id: number) {
    this.kosarService.removeFromCart(id);
    this.uzenet('A termék törölve lett a kosárból.', 'warn');
  }

  novel(id: number) {
    this.kosarService.novelMennyiseg(id);
  }

  csokkent(id: number) {
    this.kosarService.csokkentMennyiseg(id);
  }

  szamolElszallitasDatum(): string {
    const datum = new Date();

    datum.setDate(datum.getDate() + 3);

    if (datum.getDay() === 6) {
      datum.setDate(datum.getDate() + 2);
    }

    if (datum.getDay() === 0) {
      datum.setDate(datum.getDate() + 1);
    }

    return datum.toISOString().split('T')[0];
  }

  megrendeles() {
    const userAdat = localStorage.getItem('user');

    if (!userAdat) {
      this.uzenet('Nincs bejelentkezett alapítvány.', 'error');
      return;
    }

    const user = JSON.parse(userAdat);
    const alapitvanyId = user.alapitvanyId || user.id;

    if (!alapitvanyId) {
      this.uzenet('Nem található az alapítvány azonosítója.', 'error');
      return;
    }

    if (user.tipus != 1) {
      this.uzenet('Csak alapítvány tud megrendelést leadni.', 'error');
      return;
    }

    if (this.kosarService.kosar().length === 0) {
      this.uzenet('A kosár üres.', 'warn');
      return;
    }

    if (!this.pontosCim.trim()) {
      this.uzenet('Add meg a pontos címet.', 'warn');
      return;
    }

    if (!this.elszallitasDatuma) {
      this.uzenet('Add meg az elszállítás dátumát.', 'warn');
      return;
    }

    const kosarTetelek = this.kosarService.kosar();
    let sikeresDb = 0;
    let hibasDb = 0;

    kosarTetelek.forEach((termek: any) => {
      const adat = {
        alapitvanyId: alapitvanyId,
        adomanyId: termek.id,
        megrendelesDatuma: this.maiDatum,
        elszallitasDatuma: this.elszallitasDatuma,
        pontosCim: this.pontosCim, 
        mennyiseg: Number(termek.mennyiseg)
      };

      console.log('Elküldött adat:', adat);

      this.kiszallitasService.rendeles(adat).subscribe({
        next: (valasz) => {
          console.log('Sikeres rendelés:', valasz);
          sikeresDb++;

          if (sikeresDb + hibasDb === kosarTetelek.length) {
            if (hibasDb === 0) {
              this.uzenet('A megrendelés sikeresen elküldve!', 'success');
              this.kosarService.clearCart();
              this.elszallitasDatuma = this.szamolElszallitasDatum();
              this.pontosCim = '';
            } else {
              this.uzenet(`${sikeresDb} sikeres, ${hibasDb} hibás rendelés.`, 'error');
            }
          }
        },
        error: (err) => {
          console.log('Rendelési hiba:', err);
          console.log('Backend válasz:', err.error);
          hibasDb++;

          if (sikeresDb + hibasDb === kosarTetelek.length) {
            this.uzenet(`${sikeresDb} sikeres, ${hibasDb} hibás rendelés.`, 'error');
          }
        }
      });
    });
  }

  getKepUrl(kep: string): string {
    if (!kep) {
      return 'https://via.placeholder.com/80';
    }
    return 'http://127.0.0.1:8000/uploads/' + kep;
  }
}