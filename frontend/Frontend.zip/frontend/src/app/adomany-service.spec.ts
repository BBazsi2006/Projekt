import { TestBed } from '@angular/core/testing';

import { AdomanyService } from './adomany-service';

describe('AdomanyService', () => {
  let service: AdomanyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdomanyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
