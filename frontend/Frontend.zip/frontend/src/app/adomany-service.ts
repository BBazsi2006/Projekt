import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Adomany } from './models/adomany.model';
import { AdomanyNev } from './models/adomanynev.model';

@Injectable({
  providedIn: 'root',
})
export class AdomanyService {
  private apiUrl = 'http://127.0.0.1:8000/api/adomany';
  private apiUrl1 = 'http://127.0.0.1:8000/api/adomanynev';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Adomany[]> {
    return this.http.get<Adomany[]>(this.apiUrl);
  }

  getAllAdomanyNev(): Observable<AdomanyNev[]> {
    return this.http.get<AdomanyNev[]>(this.apiUrl1);
  }

  getByAdomanyozoEmail(email: string) {
    return this.http.get(`${this.apiUrl}/sajat/${email}`);
  }

  create(adat: FormData): Observable<Adomany> {
    return this.http.post<Adomany>(this.apiUrl, adat);
  }

  update(id: number, adomany: Adomany): Observable<Adomany> {
    return this.http.put<Adomany>(`${this.apiUrl}/${id}`, adomany);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
