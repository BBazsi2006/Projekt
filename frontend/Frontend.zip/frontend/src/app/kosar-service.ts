import { Injectable, signal, computed } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class KosarService {
  kosar = signal<any[]>([]);

  // Összes kosárban lévő darab
  kosarDarab = computed(() =>
    this.kosar().reduce((osszeg, t) => osszeg + t.mennyiseg, 0)
  );

  constructor() {
    this.betoltKosar();
  }

  private getUserId(): number | null {
    const userAdat = localStorage.getItem('user');

    if (!userAdat) {
      return null;
    }

    const user = JSON.parse(userAdat);

    return user.alapitvanyId || user.id || null;
  }

  private getKosarKulcs(): string | null {
    const userId = this.getUserId();

    if (!userId) {
      return null;
    }

    return `kosar_${userId}`;
  }

  betoltKosar() {
    const kulcs = this.getKosarKulcs();

    if (!kulcs) {
      this.kosar.set([]);
      return;
    }

    const mentettKosar = localStorage.getItem(kulcs);

    if (mentettKosar) {
      this.kosar.set(JSON.parse(mentettKosar));
    } else {
      this.kosar.set([]);
    }
  }

  private mentes() {
    const kulcs = this.getKosarKulcs();

    if (!kulcs) {
      return;
    }

    localStorage.setItem(kulcs, JSON.stringify(this.kosar()));
  }

  addToCart(termek: any) {
    const aktualisKosar = this.kosar();
    const index = aktualisKosar.findIndex(t => t.id === termek.id);

    // Ha még nincs bent, 1 darabbal rakjuk be
    if (index === -1) {
      const ujTermek = {
        ...termek,
        mennyiseg: 1
      };

      this.kosar.set([...aktualisKosar, ujTermek]);
      this.mentes();
      return;
    }

    // Ha már bent van, növeljük, de csak a darabszamig
    const ujKosar = [...aktualisKosar];
    const letezo = ujKosar[index];

    if (letezo.mennyiseg < letezo.darabszam) {
      ujKosar[index] = {
        ...letezo,
        mennyiseg: letezo.mennyiseg + 1
      };

      this.kosar.set(ujKosar);
      this.mentes();
    } else {
      alert('Ennél többet már nem lehet a kosárba tenni.');
    }
  }

  csokkentMennyiseg(id: number) {
    const aktualisKosar = [...this.kosar()];
    const index = aktualisKosar.findIndex(t => t.id === id);

    if (index === -1) {
      return;
    }

    const termek = aktualisKosar[index];

    if (termek.mennyiseg > 1) {
      aktualisKosar[index] = {
        ...termek,
        mennyiseg: termek.mennyiseg - 1
      };
    } else {
      aktualisKosar.splice(index, 1);
    }

    this.kosar.set(aktualisKosar);
    this.mentes();
  }

  novelMennyiseg(id: number) {
    const aktualisKosar = [...this.kosar()];
    const index = aktualisKosar.findIndex(t => t.id === id);

    if (index === -1) {
      return;
    }

    const termek = aktualisKosar[index];

    if (termek.mennyiseg < termek.darabszam) {
      aktualisKosar[index] = {
        ...termek,
        mennyiseg: termek.mennyiseg + 1
      };

      this.kosar.set(aktualisKosar);
      this.mentes();
    } else {
      alert('Nincs több készleten ebből az adományból.');
    }
  }

  removeFromCart(id: number) {
    const ujKosar = this.kosar().filter(t => t.id !== id);
    this.kosar.set(ujKosar);
    this.mentes();
  }

  clearCart() {
    this.kosar.set([]);

    const kulcs = this.getKosarKulcs();
    if (kulcs) {
      localStorage.removeItem(kulcs);
    }
  }


  
}