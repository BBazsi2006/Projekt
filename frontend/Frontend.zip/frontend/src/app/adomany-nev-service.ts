import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AdomanyNev } from './models/adomanynev.model';

@Injectable({
  providedIn: 'root',
})
export class AdomanyNevService {
   private apiUrl = 'http://127.0.0.1:8000/api/adomanynev';

  constructor(private http: HttpClient) {}

  getAll(): Observable<AdomanyNev[]> {
    return this.http.get<AdomanyNev[]>(this.apiUrl);
}
}
