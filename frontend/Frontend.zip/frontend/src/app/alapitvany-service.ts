import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Alapitvany } from './models/alapitvany.model';

@Injectable({
  providedIn: 'root',
})
export class AlapitvanyService {
   private apiUrl = 'http://127.0.0.1:8000/api/alapitvany'; 

  constructor(private http: HttpClient) { }

  getAll(): Observable<Alapitvany[]> {
    return this.http.get<Alapitvany[]>(this.apiUrl);
  }

  getById(id: number): Observable<Alapitvany> {
    return this.http.get<Alapitvany>(`${this.apiUrl}/${id}`);
  }

  create(alapitvany: Alapitvany): Observable<Alapitvany> {
    return this.http.post<Alapitvany>(this.apiUrl, alapitvany);
  }

  update(id: number, alapitvany: Alapitvany): Observable<Alapitvany> {
    return this.http.put<Alapitvany>(`${this.apiUrl}/${id}`, alapitvany);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
}
}
