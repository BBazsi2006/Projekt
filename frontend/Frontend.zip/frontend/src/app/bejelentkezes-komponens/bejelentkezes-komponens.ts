import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Router, RouterLink } from '@angular/router';
import { BejelentkezesService } from '../bejelentkezes-service';
import { KosarService } from '../kosar-service';

@Component({
  selector: 'app-bejelentkezes-komponens',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, MatFormFieldModule, MatInputModule, MatButtonModule, MatRadioModule, MatSnackBarModule
  ],
  templateUrl: './bejelentkezes-komponens.html',
  styleUrl: './bejelentkezes-komponens.css',
})
export class BejelentkezesKomponens {
  // LOGIN
  loginEmail: string = '';
  loginJelszo: string = '';

  // REGISZTRÁCIÓ
  felhasznaloTipus: number | null = null;

  // adományozó
  nev: string = '';

  // közös
  email: string = '';
  jelszo: string = '';

  // alapítvány
  cegnev: string = '';
  helyszin: string = '';
  telszam: string = '';

  constructor(
    private bejelentkezesService: BejelentkezesService,
    private router: Router,
    private kosarService: KosarService,
    private snackBar: MatSnackBar
  ) { }

  uzenet(szoveg: string, tipus: 'success' | 'error' | 'warn' = 'success') {
    this.snackBar.open(szoveg, 'Bezár', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
      panelClass: [`${tipus}-snackbar`]
    });
  }

  regisztral() {
    if (this.felhasznaloTipus == 2) {
      const adat = {
        nev: this.nev,
        email: this.email,
        jelszo: this.jelszo,
        ember: this.felhasznaloTipus
      };

      console.log('Adományozó adat:', adat);

      this.bejelentkezesService.regisztralAdomanyozo(adat).subscribe({
        next: (res) => {
          console.log(res);
          this.uzenet('Sikeres regisztráció!', 'success');

          this.nev = '';
          this.email = '';
          this.jelszo = '';
          this.cegnev = '';
          this.helyszin = '';
          this.telszam = '';
          this.felhasznaloTipus = null;
        },
        error: (err) => {
          console.log(err);
          this.uzenet('Sikertelen regisztráció.', 'error');
        }
      });
    } else if (this.felhasznaloTipus == 1) {
      const adat = {
        cegnev: this.cegnev,
        helyszin: this.helyszin,
        telszam: this.telszam,
        email: this.email,
        jelszo: this.jelszo,
        ember: this.felhasznaloTipus
      };

      console.log('Alapítvány adat:', adat);

      this.bejelentkezesService.regisztralAlapitvany(adat).subscribe({
        next: (res) => {
          console.log(res);
          this.uzenet('Sikeres regisztráció!', 'success');

          this.nev = '';
          this.email = '';
          this.jelszo = '';
          this.cegnev = '';
          this.helyszin = '';
          this.telszam = '';
          this.felhasznaloTipus = null;
        },
        error: (err) => {
          console.log(err);
          this.uzenet('Sikertelen regisztráció.', 'error');
        }
      });
    } else {
      this.uzenet('Válassz felhasználótípust!', 'warn');
    }
  }

  belepes() {
    const adat = {
      email: this.loginEmail,
      jelszo: this.loginJelszo
    };

    console.log('Login adat:', adat);

    this.bejelentkezesService.belepes(adat).subscribe({
      next: (valasz: any) => {
        console.log('BEJELENTKEZÉS VÁLASZ:', valasz);

        const admin = this.loginEmail === 'admin@gmail.com';

        const user = {
          ...valasz,
          admin: admin
        };


        localStorage.setItem('user', JSON.stringify(user));
        this.kosarService.betoltKosar();

        this.uzenet('Sikeres bejelentkezés!', 'success');

        if (admin) {
          this.router.navigate(['/kiszallitasok']);
        }
        else if (valasz.tipus == 1) {
          this.router.navigate(['/alapitvanyok']);
        }
        else if (valasz.tipus == 2) {
          this.router.navigate(['/adomanyok']);
        }
        else {
          alert("Ismeretlen felhasználótípus");
        }


      },
      error: (err) => {
        console.log(err);
        this.uzenet('Hibás email vagy jelszó.', 'error');
      }
    });
  }
}