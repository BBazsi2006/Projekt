import { TestBed } from '@angular/core/testing';

import { AdomanyozoService } from './adomanyozo-service';

describe('AdomanyozoService', () => {
  let service: AdomanyozoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdomanyozoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
