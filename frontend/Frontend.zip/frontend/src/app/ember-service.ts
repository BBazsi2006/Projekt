import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Ember } from './models/ember.model';

@Injectable({
  providedIn: 'root',
})
export class EmberService {
  private apiUrl = 'http://localhost:8000/api/ember';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Ember[]> {
    return this.http.get<Ember[]>(this.apiUrl);
  }
}
