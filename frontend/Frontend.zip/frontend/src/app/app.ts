import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavigacioKomponens } from './navigacio-komponens/navigacio-komponens';
import { FooldalKomponens } from './fooldal-komponens/fooldal-komponens';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,NavigacioKomponens,FooldalKomponens],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('projekt');
}
