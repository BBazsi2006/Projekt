import { Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { FooldalKomponens } from './fooldal-komponens/fooldal-komponens';
import { AdomanyokKomponens } from './adomanyok-komponens/adomanyok-komponens';
import { BejelentkezesKomponens } from './bejelentkezes-komponens/bejelentkezes-komponens';
import { KosarKomponens } from './kosar-komponens/kosar-komponens';
import { AlapitvanyokKomponens } from './alapitvanyok-komponens/alapitvanyok-komponens';
import { RolunkKomponens } from './rolunk-komponens/rolunk-komponens';
import { KiszallitasKomponens } from './kiszallitas-komponens/kiszallitas-komponens';

export const routes: Routes = [
  { path: '', component: FooldalKomponens },
  { path: 'adomanyok', component: AdomanyokKomponens },
  { path: 'alapitvanyok', component: AlapitvanyokKomponens },
  { path: 'bejelentkezes', component: BejelentkezesKomponens },
  { path: 'rolunk', component: RolunkKomponens },
  { path: 'kosar', component: KosarKomponens },
  { path: 'kiszallitasok', component: KiszallitasKomponens }
];

