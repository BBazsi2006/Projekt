import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Anyag } from './models/anyag.model';

@Injectable({
  providedIn: 'root',
})
export class AnyagService {
   private apiUrl = 'http://localhost:8000/api/anyag';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Anyag[]> {
    return this.http.get<Anyag[]>(this.apiUrl);
  }
}
