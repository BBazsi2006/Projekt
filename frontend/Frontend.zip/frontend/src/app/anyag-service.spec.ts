import { TestBed } from '@angular/core/testing';

import { AnyagService } from './anyag-service';

describe('AnyagService', () => {
  let service: AnyagService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AnyagService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
