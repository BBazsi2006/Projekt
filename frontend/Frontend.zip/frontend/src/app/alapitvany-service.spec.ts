import { TestBed } from '@angular/core/testing';

import { AlapitvanyService } from './alapitvany-service';

describe('AlapitvanyService', () => {
  let service: AlapitvanyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlapitvanyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
